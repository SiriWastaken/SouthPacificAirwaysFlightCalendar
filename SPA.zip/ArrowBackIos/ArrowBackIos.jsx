import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <img className="arrow-back-ios" alt="Arrow back ios" src="arrow-back-ios.png" />
    </div>
  );
};
