import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <div className="group">
        <div className="text-wrapper">SPA Flight Calendar</div>
        <div className="div">Build 15</div>
      </div>
    </div>
  );
};
