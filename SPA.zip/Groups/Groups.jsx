import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <img className="groups" alt="Groups" src="groups.svg" />
    </div>
  );
};
