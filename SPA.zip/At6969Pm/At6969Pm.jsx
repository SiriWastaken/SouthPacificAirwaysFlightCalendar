import React from "react";
import "./style.css";

export const Label = () => {
  return (
    <div className="label">
      <div className="text-wrapper">... at 69:69 PM</div>
    </div>
  );
};
