import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <img className="today" alt="Today" src="today.png" />
    </div>
  );
};
