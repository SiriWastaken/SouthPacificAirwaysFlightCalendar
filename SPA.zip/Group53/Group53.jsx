import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <div className="group">
        <div className="text-wrapper">SPA69</div>
        <div className="div">to Toronto</div>
        <div className="text-wrapper-2">... at 69:69 PM</div>
      </div>
    </div>
  );
};
