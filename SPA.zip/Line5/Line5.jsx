import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <img className="line" alt="Line" src="line-5.svg" />
    </div>
  );
};
