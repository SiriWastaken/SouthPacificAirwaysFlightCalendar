import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <img className="flight-takeoff" alt="Flight takeoff" src="flight-takeoff.png" />
    </div>
  );
};
