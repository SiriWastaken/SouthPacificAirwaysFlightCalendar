import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <div className="group">
        <div className="overlap-group">
          <div className="text-wrapper">Go to Flight</div>
        </div>
      </div>
    </div>
  );
};
