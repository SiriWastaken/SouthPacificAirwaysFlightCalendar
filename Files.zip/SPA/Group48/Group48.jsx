import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <div className="group">
        <div className="text-wrapper">sticksgobyebye</div>
        <div className="div">Chief Cool Guy</div>
      </div>
    </div>
  );
};
