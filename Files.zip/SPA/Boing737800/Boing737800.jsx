import React from "react";
import "./style.css";

export const Label = () => {
  return (
    <div className="label">
      <div className="text-wrapper">Boing 737-800</div>
    </div>
  );
};
