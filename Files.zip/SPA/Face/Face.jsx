import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <img className="face" alt="Face" src="face.png" />
    </div>
  );
};
