import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <img className="travel" alt="Travel" src="travel.png" />
    </div>
  );
};
