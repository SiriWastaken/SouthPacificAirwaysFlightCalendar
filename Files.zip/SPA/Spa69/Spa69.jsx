import React from "react";
import "./style.css";

export const Label = () => {
  return (
    <div className="label">
      <div className="text-wrapper">SPA69</div>
    </div>
  );
};
