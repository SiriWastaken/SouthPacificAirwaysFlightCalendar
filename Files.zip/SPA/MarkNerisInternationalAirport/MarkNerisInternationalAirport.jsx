import React from "react";
import "./style.css";

export const Label = () => {
  return (
    <div className="label">
      <div className="text-wrapper">Mark Neris International Airport</div>
    </div>
  );
};
